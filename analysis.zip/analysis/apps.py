from django.apps import AppConfig


class CsvAnalysisConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'csv_analysis'
